#!/usr/bin/env bash

/root/jdk1.8/jdk1.8.0_171/bin/java -Xdebug -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005 -jar /root/export/jvm-sandbox-user-demo/sandbox-user-demo-1.4.0.jar -server -Xmx200m -Xms200m -Xmn100m -XX:PermSize=128m -XX:MaxPermSize=256m -Xss256k -XX:SurvivorRatio=8 -XX:MaxTenuringThreshold=15 -XX:PretenureSizeThreshold=20971520 -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -verbose:gc -Xloggc:gc.log -Dfile.encoding=UTF8 -Dsun.jnu.encoding=UTF8 -Xdebug -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005
